<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

use App\Models\LandDetails;
use App\Models\LandVillages;
use App\Models\Application;

class LandDetailsController extends Controller
{
    public function handleLandData(Request $request){
        
        \Log::info('Received Request - ', [$request->getContent()]);
        
        $requestParam = $request->getContent();
        try {
            $reqParam = json_decode($requestParam,true);
        
            /**Validate Paramteres */
            $inputValidationResult = $this->validateRequestParam($reqParam);
            
            /**Validate Success */ 
            if($inputValidationResult['status'] != 'success'){
                return response()->json([
                    'status' => $inputValidationResult['status'],
                    'messages' => $inputValidationResult['messages'],
                    'code' => '614'
                ], 200);
            }

            /**
            * Store Land Data to Data base table Land Details
            */
            if($reqParam['is_land_holder'] == "true"){
                $villageDetails = LandVillages::where('village_code',$reqParam['village_code'])
                    ->get()
                    ->first();
                if(!empty($villageDetails)){
                    $villageDetailsArr = $villageDetails->toArray();
                    $village_name = $villageDetailsArr['village_name'];
                }else{
                    $village_name = '';
                }
            }
		    $existing_allied_activity = json_encode($reqParam['existing_allied_activity']);
            /*if($reqParam['other_allied_activities'] == "true"){
                $existing_allied_activity = json_encode($reqParam['existing_allied_activity']);
            }else{
                $existing_allied_activity = "no";
	        }*/
            
            if($reqParam['is_land_holder'] == "true"){
                $nature_of_land = $reqParam['nature_of_land'];
                $total_area_hectare = $reqParam['total_area_hectare'];
            }else{
                $nature_of_land = "no";
                $total_area_hectare = "no";
            }
            if($reqParam['is_land_holder'] != "false" && $reqParam['other_allied_activities'] != "false"){
                $storeLandDtlStatus = new LandDetails();
                
                $result = $storeLandDtlStatus->updateOrCreate(
                    [
                        'application_id' => $reqParam['applicationId']
                    ],
                    [
                        'is_land_holder' => $reqParam['is_land_holder'],
                        'other_allied_activities' => $reqParam['other_allied_activities'],
                        'nature_of_land' => $nature_of_land,
                        'total_area_hectare' => $total_area_hectare,
                        'existing_allied_activity' => $existing_allied_activity,
                        'state_code' => $reqParam['state_code'],
                        'district_code' => $reqParam['district_code'],
                        'block_code' => $reqParam['block_code'],
                        'village_code' => $reqParam['village_code'],
                        'village_name' => $village_name,
                        'survey_number' => $reqParam['survey_number'],
                        'khata_number' => $reqParam['khata_number'],
                        'land_ownership_type' => $reqParam['land_ownership_type'],
                        'land_type' => $reqParam['land_type'],
                        'land_area_acre' => $reqParam['land_area_acre'],
                        'encumbrance' => $reqParam['encumbrance'],
                        'water_source' => $reqParam['water_source'],
                        'fodder_source' => $reqParam['fodder_source'],
                    ]
            
                );
                $current_step = 'loan_data';
                $section_id = 'loan_details';
                
                if($result == true){
                    $updateApplicationDtlStatus = Application::where('application_id', $reqParam['applicationId'])->update(['app_status' => 'in-process', 'section_id'=>$section_id, 'current_step'=>$current_step]);
                }else{
                    return response()->json([
                        'status' => 'error',
                        'messages' => 'Somthing went wrong while registering land details',
                        'code' => '617'
                    ], 200);
                }

                if ($result == true && $updateApplicationDtlStatus > 0) {
                    return response()->json([
                        'status' => 'success',
                        'messages' => 'Land details registered successfully',
                        'code' => '200'
                    ], 200);
                }else{
                    return response()->json([
                        'status' => 'error',
                        'messages' => 'Somthing went wrong while registering land details',
                        'code' => '617'
                    ], 200);
                }
            }else{
                $current_step = 'rejected';
                $section_id = 'not_eligible';
                
                $updateApplicationDtlStatus = Application::where('application_id', $reqParam['applicationId'])->update(['app_status' => 'reject', 'section_id'=>$section_id, 'current_step'=>$current_step]);

                if ($updateApplicationDtlStatus > 0) {
                    return response()->json([
                        'status' => 'success',
                        'messages' => 'Application updated successfully',
                        'code' => '200'
                    ], 200);
                }else{
                    return response()->json([
                        'status' => 'error',
                        'messages' => 'Somthing went wrong while registering land details',
                        'code' => '617'
                    ], 200);
                }
            }
            
        }catch(\Exception $e){
            return response()->json([
                'status' => 'error',
                'messages' => 'Somthing went wrong, please review error >>>> '.$e->getMessage(),
                'code' => '400'
            ], 400);
        }
    }

    public function validateRequestParam($reqParam){
        
        if($reqParam['is_land_holder'] == "true"){
            $rules = [
                'applicationId' => 'required|regex:/^APP\d+$/',
                'is_land_holder' => 'required',
                'other_allied_activities' => 'required',
                'land_area_acre' => 'required',
                'land_type' => 'required',
                'land_ownership_type' => 'required',
                'encumbrance' => 'required',
                'water_source' => 'required',
                'fodder_source' => 'required',
                'state_code' => 'required',
                'district_code' => 'required',
                'block_code' => 'required',
                'village_code' => 'required',
                'survey_number' => 'required',
                'khata_number' => 'required',
                
            ];

            $messages = [
                'applicationId.required' => 'The application ID field is required',
                'applicationId.regex' => 'The application ID field is not valid',
            ];
            $validator = Validator::make($reqParam, $rules, $messages);
            if($validator->errors() && !empty($validator->errors()->toArray())){
                return $validationArr = ['status' => 'error', 'messages' => $validator->errors()->toArray()];
            }else{
                return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
            }
            return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
        }else{
            return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
        }
        if($reqParam['other_allied_activities'] == "true"){
            $rules = [
                'applicationId' => 'required|regex:/^APP\d+$/',
                'is_land_holder' => 'required',
                'other_allied_activities' => 'required'
            ];

            $messages = [
                'applicationId.required' => 'The application ID field is required',
                'applicationId.regex' => 'The application ID field is not valid',
            ];
            $validator = Validator::make($reqParam, $rules, $messages);
            if($validator->errors() && !empty($validator->errors()->toArray())){
                return $validationArr = ['status' => 'error', 'messages' => $validator->errors()->toArray()];
            }else{
                return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
            }
            return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
        }else{
            return $validationArr = ['status' => 'success', 'messages' => 'Request Data Validate Successfully'];
        }
    }
}
